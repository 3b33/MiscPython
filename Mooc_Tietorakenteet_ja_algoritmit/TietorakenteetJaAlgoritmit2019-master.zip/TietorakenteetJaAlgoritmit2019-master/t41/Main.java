import java.util.*;

public class Main {
    public static void main(String[] args) {
        Permutaatiot p = new Permutaatiot();
        System.out.println(p.laske(1)); // 1
        System.out.println(p.laske(2)); // 0
        System.out.println(p.laske(3)); // 0
        System.out.println(p.laske(4)); // 2
    }
}