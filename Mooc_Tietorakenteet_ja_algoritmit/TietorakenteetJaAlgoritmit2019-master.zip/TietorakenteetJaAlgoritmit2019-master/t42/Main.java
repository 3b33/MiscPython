import java.util.*;

public class Main {
    public static void main(String[] args) {
        Latinalaiset l = new Latinalaiset();
        System.out.println(l.laske(1)); // 1
        System.out.println(l.laske(2)); // 2
        System.out.println(l.laske(3)); // 12
        System.out.println(l.laske(4)); // 576 
		//System.out.println(l.laske(5)); //161280
    }
}