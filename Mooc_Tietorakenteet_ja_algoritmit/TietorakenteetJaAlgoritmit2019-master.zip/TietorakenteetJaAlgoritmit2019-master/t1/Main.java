import java.util.*;

public class Main {
    public static void main(String[] args) {
        Numerot n = new Numerot();
        System.out.println(n.summa(4075)); // 16
        System.out.println(n.summa(3)); // 3
        System.out.println(n.summa(999999999)); // 81
    }
}