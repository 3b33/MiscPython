import java.util.*;

public class Main {
    public static void main(String[] args) {
        Pysakit p = new Pysakit();
        System.out.println(p.laske(new int[] {3,7,1,5}, 1)); // 2
        System.out.println(p.laske(new int[] {3,7,1,5}, 2)); // 2
        System.out.println(p.laske(new int[] {3,7,1,5}, 3)); // 1    
    }
}