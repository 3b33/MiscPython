import java.util.*;

public class Main {
    public static void main(String[] args) {
        Nopanheitto n = new Nopanheitto();
        System.out.println(n.laske(1)); // 1
        System.out.println(n.laske(2)); // 2
        System.out.println(n.laske(4)); // 8
		System.out.println(n.laske(7));	//63
        System.out.println(n.laske(10)); // 492
    }
}