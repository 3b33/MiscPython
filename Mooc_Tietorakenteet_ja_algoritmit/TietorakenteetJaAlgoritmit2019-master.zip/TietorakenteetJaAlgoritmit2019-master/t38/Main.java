import java.util.*;

public class Main {
    public static void main(String[] args) {
        Merkkijonot m = new Merkkijonot();
        System.out.println(m.muodosta(1)); // [A, B]
        System.out.println(m.muodosta(2)); // [AA, AB, BA, BB]
        System.out.println(m.muodosta(3)); // [AAA, AAB, ABA, ABB, BAA, BAB, BBA, BBB]
    }
}