import java.util.*;

public class Main {
    public static void main(String[] args) {
        KolmenSumma k = new KolmenSumma();
        System.out.println(k.laske(9)); // 3
        System.out.println(k.laske(2)); // 0
        System.out.println(k.laske(99)); // 768
    }
}