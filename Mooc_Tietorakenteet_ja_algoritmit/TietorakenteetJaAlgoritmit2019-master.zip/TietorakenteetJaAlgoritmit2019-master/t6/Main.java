import java.util.*;

public class Main {
    public static void main(String[] args) {
        Onnenluvut o = new Onnenluvut();
		System.out.println(o.laske(3,3)); // 1
		System.out.println(o.laske(1,336)); // 7
        System.out.println(o.laske(1,10)); // 2*/
        System.out.println(o.laske(3337,7333)); // 5
        System.out.println(o.laske(1,1000000)); // 126
		System.out.println(o.laske(32,3377)); // 16
		System.out.println(o.laske(377373337,777377333)); //264
		//System.out.println(o.laske(1,777377333)); //264
		//System.out.println(o.laske(1,377373337)); //264
    }
}