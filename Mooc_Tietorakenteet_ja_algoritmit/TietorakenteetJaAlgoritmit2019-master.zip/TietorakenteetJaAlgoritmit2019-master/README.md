## Tietorakenteet ja algoritmit, 2019
Java (Helsingin yliopisto: MOOC)

Tehokkaat algoritmit: 
- järjestäminen
- lista- ja joukkorakenteet
- dynaaminen ohjelmointi
- verkkoalgoritmit
